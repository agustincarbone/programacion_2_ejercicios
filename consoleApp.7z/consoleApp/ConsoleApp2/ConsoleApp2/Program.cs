﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "ejercicio #2";
            int i;
            int j;
            int numero;
            int divisores = 0;

            numero = int.Parse(Console.ReadLine());


            for (i=2; i<=numero; i++)
            {

                for (j=1; j<=i; j++)
                {
                    if (i % j == 0)
                    {
                        divisores++;
                    }
                }

                if (divisores == 2)
                {
                    Console.WriteLine(i);
                }

                divisores = 0;
            }

            Console.ReadKey();
        }
    }
}
