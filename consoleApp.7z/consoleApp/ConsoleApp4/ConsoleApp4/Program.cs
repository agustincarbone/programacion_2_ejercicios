﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "ejercicio #4";
            int i,j;
            int numero;            
            int listaA = 0;
            int listaB = 0;

            numero = int.Parse(Console.ReadLine());

            for (i = 1; i <= numero; i++)
            {
                for (j = 1; (listaB < listaA) || (listaA==0 && listaB==0); j++)
                {
                    if (j < i)
                    {
                        listaA += j;
                    }else if(j > i)
                    {
                        listaB += j;
                    }
                }

                if (listaB == listaA)
                {
                    Console.WriteLine(i);
                }

                listaA = 0;
                listaB = 0;
            }

            Console.ReadKey();


        }
    }
}
