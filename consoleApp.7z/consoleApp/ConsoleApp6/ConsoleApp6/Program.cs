﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "ejercicio #6";

            DateTime fechaActual = DateTime.Today;
            /*int dia;
            int mes;
            int año;

            Console.WriteLine("ingrese fecha de nacimiento ( dia mes año) separar con ENTER");

            dia = int.Parse(Console.ReadLine());
            mes = int.Parse(Console.ReadLine());
            año = int.Parse(Console.ReadLine());*/

            DateTime.
            int.Parse(fechaActual);
            Console.WriteLine(fechaActual);

            Console.ReadKey();


        }
    }
}
