﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "ejercicio #1";
            int numero = 0;

            numero = int.Parse(Console.ReadLine());
            
            Console.WriteLine(Math.Pow(numero, 2));
            Console.WriteLine(Math.Pow(numero, 3));
            Console.ReadKey();
        }
    }
}
