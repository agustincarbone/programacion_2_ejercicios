﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "ejercicio #3";
            int i,j;
            int numero;
            int acumDivisores = 0;
            int numEncontrados = 0;

            Console.WriteLine("indique la cantidad de numeros perfectos a bucar");
            numero = int.Parse(Console.ReadLine());

            for(i=1; numEncontrados<numero; i++)
            {
                for (j=1; j<i; j++)
                {
                    if (i % j == 0)
                    {
                        acumDivisores += j;
                    }
                }

                if (acumDivisores == i)
                {
                    numEncontrados++;
                    Console.WriteLine(i);
                }
                acumDivisores = 0;
            }

            Console.ReadKey();
        }
    }
}
